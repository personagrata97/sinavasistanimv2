import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import {
  extractAllText,
  checkPdfQuality,
  assessPdfSearchability,
  detectSectionsMultimodal,
  joinPageTextsForRange,
  NATIVE_TEXT_LOG_MESSAGE,
  SCANNED_PDF_PENDING_OCR,
  isPendingOcrContent,
  shouldRunMarkdownOcr,
  prepareSearchablePdfSectionContent,
} from "@/lib/pdf-engine"
import {
  buildSingleSectionFromPages,
  detectSectionsSystematic,
  sectionsToDetected,
} from "@/lib/section-detector"
import { analyzeSectionContent, generateCourseNotes, generateFlashcards, generateQuestions, setFileUrisMap, auditNotesAgainstSourceSpecific, validateQuestionsWithSolver, validateFlashcardsWithSolver, verifyNotesAgainstSource, needsBilingualStudyItems, translateFlashcardsToEnglish, translateQuestionsToEnglish, validateBilingualPairs, ApiQuotaExhaustedError, OcrChunkRateLimitError } from "@/lib/ai-service"
import { resolveRequiresQuestions } from "@/lib/glossary-utils"
import { getExamConfig, getCourseBySlug } from "@/lib/course-data"
import {
  formatProcessingProfileLog,
  getDocumentNoteInstructions,
  getDocumentProcessingProfile,
} from "@/lib/document-processing-profile"
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import {
  getStudyNotFoundMessage,
  getNotesGenerationPhaseLabel,
  isProfessionalProgram,
} from "@/lib/program-catalog"
import { readFile } from "fs/promises"
import {
  activeProcesses,
  cancelCourseProcessing,
  clearCancelSignal,
  clearHeartbeat,
  hasFreshHeartbeat,
  isCancelled,
  isHeartbeatStale,
  isWorkerLive,
  recordHeartbeat,
  releaseProcessing,
  STALE_PROCESS_MAX_AGE_MS,
  tryClaimProcessing,
} from "@/lib/process-registry"
import { pauseOrphanedProcessingOnBoot } from "@/lib/process-startup"
import {
  HEARTBEAT_STALE_MESSAGE,
  clearProcessTriggerDebounce,
  pauseGhostProcessingInDb,
} from "@/lib/course-processing-status"
import {
  isAdminSession,
  MAX_NOTES_GENERATION_RETRIES,
  MAX_OCR_ROUTE_ATTEMPTS,
  MAX_QUOTA_FAILURES_PER_SECTION,
  MAX_SECTION_OUTER_RETRIES,
  PROCESS_TRIGGER_DEBOUNCE_MS,
  RECENT_API_ACTIVITY_MS,
  computeDebounceRemainingMs,
  debounceUntilIso,
  sectionsLookValid,
  shouldApplyProcessTriggerDebounce,
} from "@/lib/quota-guard"
import {
  mergeVerificationIssues,
  stringifyMergedVerificationIssues,
} from "@/lib/section-quality-gates"

// Chapter/section detection patterns for Turkish academic PDFs
const SECTION_PATTERNS = [
  /^(BÖLÜM|Bölüm|bölüm)\s*(\d+)\s*[:.–-]\s*(.+)/,
  /^(KONU|Konu)\s*(\d+)\s*[:.–-]\s*(.+)/,
  /^(\d+)\.\s+(BÖLÜM|KONU|KISIM)\s*[:.–-]?\s*(.+)/i,
  /^(\d+)\.\s+([A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜa-zçğıöşü\s]{10,})/,
  /^(ÜNİTE|Ünite)\s*(\d+)\s*[:.–-]\s*(.+)/,
  /^\d+\.\d*\s+[A-ZÇĞİÖŞÜ]{2,}/,
]

interface DetectedSection {
  title: string
  pageStart: number
  pageEnd: number
  content: string
  module?: string
}

// ==================== KARAKTER BAZLI CHUNK BOYUTU ====================
// Büyük chunk = daha derin içerik, daha kaliteli sorular
// 1 sayfa ortalama ~2000 karakter → 12-15 sayfa = 25000 karakter
// Küçük chunk'lar sığ/tekrarlı içerik üretiyor!
const MAX_CHUNK_CHARS = 12000 // ~5 sayfa = daha detaylı, eksik konu riski düşük

/** Son birkaç dakikada bu derse ait API hareketi var mı? Yoksa arka plan işi kopmuş olabilir. */
async function hasRecentCourseApiActivity(slug: string): Promise<boolean> {
  const since = new Date(Date.now() - RECENT_API_ACTIVITY_MS)
  const hit = await prisma.apiUsageLog.findFirst({
    where: {
      createdAt: { gte: since },
      courseSlug: slug,
    },
    select: { id: true },
  })
  return !!hit
}

export async function POST(req: NextRequest) {
  try {
    await pauseOrphanedProcessingOnBoot()

    const body = await req.json()
    const session = await getServerSession(authOptions)
    const isCron = Boolean(process.env.CRON_SECRET && body.secretToken === process.env.CRON_SECRET)
    if (!session?.user?.email && !isCron) {
      console.warn("[PROCESS] 🔴 Yetkisiz tetikleme engellendi.")
      return NextResponse.json({ error: "Yetkilendirme gerekli" }, { status: 401 })
    }

    const { slug, forceRetry = false, userInitiated = false, source: bodySource } = body
    if (!slug) return NextResponse.json({ error: "Missing slug" }, { status: 400 })

    const explicitResume = userInitiated || forceRetry

    // 🚨 SIFIR OTOMATİK TETİKLEME — yalnızca kullanıcı butonu / zorla / cron
    if (!explicitResume && !isCron) {
      console.warn(`[PROCESS] 🔴 Kullanıcı onayı olmadan tetikleme reddedildi: ${slug}`)
      return NextResponse.json(
        {
          error: "İşleme yalnızca «İşleme Başlat» veya «Devam Ettir» ile başlatılabilir.",
          needsUserAction: true,
        },
        { status: 403 },
      )
    }

    const course = await prisma.course.findUnique({
      where: { slug },
      include: { program: true }
    })
    if (!course) {
      return NextResponse.json(
        { error: `${getStudyNotFoundMessage(slug.startsWith("zeliha-") ? "zeliha-mevzuat" : "")}.` },
        { status: 404 },
      )
    }

    const isAdmin = isAdminSession(session?.user)

    if (forceRetry && !isAdmin && !isCron) {
      console.warn(`[PROCESS] 🔴 Zorla devam yalnızca yönetici: ${slug}`)
      return NextResponse.json(
        { error: "Zorla devam yalnızca yönetici hesabıyla kullanılabilir." },
        { status: 403 },
      )
    }

    const workerAlive =
      course.status === "processing" && isWorkerLive(slug)
    const heartbeatFresh = hasFreshHeartbeat(slug)

    const recentDuplicate = await prisma.processTriggerLog.findFirst({
      where: {
        courseSlug: slug,
        createdAt: { gte: new Date(Date.now() - PROCESS_TRIGGER_DEBOUNCE_MS) },
      },
      orderBy: { createdAt: "desc" },
    })

    const debounceApplies =
      recentDuplicate &&
      shouldApplyProcessTriggerDebounce({
        workerLive: workerAlive,
        courseStatus: course.status,
        hasFreshHeartbeat: heartbeatFresh,
      })

    if (debounceApplies && !(forceRetry && isAdmin)) {
      const retryAfterMs = computeDebounceRemainingMs(recentDuplicate!.createdAt)
      console.warn(
        `[PROCESS] 🔴 60 sn içinde tekrar tetikleme reddedildi (işçi canlı): ${slug}`,
      )
      return NextResponse.json(
        {
          message: `Bu modüle az önce işlem başlatıldı. Lütfen ${Math.ceil(retryAfterMs / 1000)} saniye bekleyin.`,
          duplicateTrigger: true,
          alreadyRunning: workerAlive,
          workerLive: workerAlive,
          retryAfterSeconds: Math.ceil(retryAfterMs / 1000),
          debounceUntil: debounceUntilIso(recentDuplicate!.createdAt),
        },
        { status: 429 },
      )
    }

    if (recentDuplicate && !debounceApplies) {
      console.log(
        `[PROCESS] 🧹 Eski tetikleme kaydı — işçi yok, debounce atlanıyor: ${slug}`,
      )
      await clearProcessTriggerDebounce(slug)
    }

    if (workerAlive) {
      if (forceRetry && isAdmin) {
        // Zorla devam: Önce eski işçiyi durdur, kilidini temizle, SONRA yenisini başlat
        console.log(`[PROCESS] ⚠️ Zorla devam: Eski işçi durduruluyor → ${course.name}`);
        cancelCourseProcessing(slug, course.name);
        releaseProcessing(slug);
        clearHeartbeat(slug);
        await clearProcessTriggerDebounce(slug);
        // Eski işçinin iptal sinyalini alıp çıkması için kısa bekleme
        await new Promise(r => setTimeout(r, 3000));
        console.log(`[PROCESS] ✅ Eski işçi durduruldu, yeni motor başlatılıyor → ${course.name}`);
      } else {
        console.log(`[PROCESS] 🔒 Tek uçuş kilidi: ${course.name} zaten işleniyor`)
        return NextResponse.json(
          {
            message: "Bu modül zaten işleniyor. Bitmesini bekleyin; tekrar «Devam Ettir» tıklamayın.",
            alreadyRunning: true,
          },
          { status: 200 },
        )
      }
    }

    try {
      const triggerSource = isCron
        ? "cron"
        : (bodySource as string) ||
          (forceRetry ? "force_retry" : userInitiated ? "user_button" : "unknown")
      await prisma.processTriggerLog.create({
        data: {
          courseSlug: slug,
          userId: session?.user?.id ?? null,
          userEmail: session?.user?.email ?? null,
          forceRetry: Boolean(forceRetry),
          source: triggerSource,
        },
      })
      console.log(
        `[PROCESS] 📋 Tetikleme kaydı: ${slug} ← ${triggerSource} (${session?.user?.email ?? "cron"})`,
      )
    } catch (auditErr) {
      console.warn("[PROCESS] Tetikleme kaydı yazılamadı:", auditErr)
    }

    // İptal edilmiş iş — kullanıcı açıkça devam ettirmedikçe yeniden başlatma
    if (isCancelled(slug, course.name) && !explicitResume) {
      console.log(`[PROCESS] 🛑 İptal edilmiş iş — otomatik devam engellendi: ${course.name}`)
      return NextResponse.json(
        {
          message: "Bu modül durdurulmuş. Devam ettirmek için «Devam Ettir» butonuna tıklayın.",
          needsUserAction: true,
        },
        { status: 200 },
      )
    }

    if (explicitResume) {
      clearCancelSignal(slug, course.name)
    }

    recordHeartbeat(slug, true)

    // Duraklatılmış / hatalı modül — sayfa açılışı veya arka plan tetiklemesiyle otomatik başlatma
    if ((course.status === "paused" || course.status === "error") && !explicitResume) {
      console.log(`[PROCESS] ⏸️ Duraklatılmış modül — kullanıcı onayı olmadan başlatılmıyor: ${course.name}`)
      return NextResponse.json(
        {
          message: "Modül duraklatılmış. Devam ettirmek için «Devam Ettir» butonuna tıklayın.",
          needsUserAction: true,
        },
        { status: 200 },
      )
    }

    const staleProcess =
      course.status === "processing" &&
      !explicitResume &&
      !(await hasRecentCourseApiActivity(slug)) &&
      !activeProcesses.has(slug)

    const processAgeMs = Date.now() - course.updatedAt.getTime()
    const isOldProcessing =
      course.status === "processing" && processAgeMs > STALE_PROCESS_MAX_AGE_MS && !explicitResume

    // Kopuk veya çok eski işlem — OTOMATİK DEVAM ETME, duraklat
    if ((staleProcess || isOldProcessing) && !explicitResume) {
      const pauseMessage =
        "Eski arka plan işi duraklatıldı (otomatik devam kapalı). «Devam Ettir» ile yeniden başlatın."
      console.log(`[PROCESS] 🧟 Kopuk/eski işlem duraklatıldı (otomatik devam yok): ${course.name}`)
      releaseProcessing(slug)
      const pendingSection = await prisma.section.findFirst({
        where: { courseId: course.id, processed: false },
        orderBy: { order: "asc" },
        select: { id: true, verificationIssues: true },
      })
      if (pendingSection) {
        await prisma.section.update({
          where: { id: pendingSection.id },
          data: {
            verificationIssues: stringifyMergedVerificationIssues(pendingSection.verificationIssues, {
              currentMicroPhase: pauseMessage,
              pauseReason: staleProcess ? "stale_worker" : "stale_age",
              pausedAt: new Date().toISOString(),
            }),
          },
        })
      }
      await prisma.course.update({
        where: { slug },
        data: { status: "paused", updatedAt: new Date() },
      })
      return NextResponse.json(
        { message: pauseMessage, stalePaused: true, needsUserAction: true },
        { status: 200 },
      )
    }

    // 🔒 TEK GLOBAL İŞ — başka bir ders işlenirken yeni iş başlatma
    const globalBlock = tryClaimProcessing(slug)
    if (!globalBlock.ok && !forceRetry) {
      console.log(`[PROCESS] 🔒 Global kilit: ${course.name} bekliyor (${globalBlock.blockedBy} aktif)`)
      return NextResponse.json(
        {
          message: `Başka bir modül işleniyor. Lütfen önce onun bitmesini bekleyin veya durdurun.`,
          alreadyRunning: true,
          blockedBy: globalBlock.blockedBy,
        },
        { status: 200 },
      )
    }

    // 🔒 ÇİFT TIKLAMA KORUMASI — gerçekten çalışan işlemi koru
    if (course.status === "processing" && !explicitResume) {
      const timeSinceLastUpdate = Date.now() - course.updatedAt.getTime()

      if (timeSinceLastUpdate < 15 * 60 * 1000) {
        console.log(`[PROCESS] ⚠️ Zaten işlemde (${Math.round(timeSinceLastUpdate / 1000)}sn önce güncellendi): ${course.name}`)
        return NextResponse.json(
          { message: "İşlem arka planda aktif olarak devam ediyor. Lütfen bekleyin.", alreadyRunning: true },
          { status: 200 },
        )
      }
      if (!forceRetry) {
        console.log(`[PROCESS] ⏸️ 15 dk hareketsiz — otomatik devam yok, duraklatılıyor: ${course.name}`)
        releaseProcessing(slug)
        await prisma.course.update({
          where: { slug },
          data: { status: "paused", updatedAt: new Date() },
        })
        return NextResponse.json(
          {
            message: "İşlem yanıt vermiyor. «Devam Ettir» veya «Zorla» ile yeniden başlatın.",
            needsUserAction: true,
          },
          { status: 200 },
        )
      }
      console.log(`[PROCESS] 🔄 Zorla devam: ${course.name}`)
    }

    if (forceRetry) {
      releaseProcessing(slug)
      tryClaimProcessing(slug)
    }

    if (activeProcesses.has(slug) && course.status === "processing" && isWorkerLive(slug) && !explicitResume) {
      console.log(`[PROCESS] ⚠️ Bellekte aktif işlem: ${course.name}`)
      return NextResponse.json(
        { message: "İşlem zaten arka planda devam ediyor. Lütfen birkaç dakika bekleyin.", alreadyRunning: true },
        { status: 200 },
      )
    }

    if (!activeProcesses.has(slug)) {
      tryClaimProcessing(slug)
    }

    // Update status
    await prisma.course.update({
      where: { slug },
      data: { status: "processing" }
    })

    // Zombi dedektörünün anında öldürmesini engellemek için kalan bölümlerin updatedAt'ini tazele
    await prisma.section.updateMany({
      where: { courseId: course.id, processed: false },
      data: { updatedAt: new Date() },
    })

    // Read PDF buffer
    if (!course.pdfPath) throw new Error("PDF Path not found");
    const pdfBuffer = await readFile(course.pdfPath)
    const totalPages = course.totalPages

    // ========== PHASE 1 & 2: Extract text & detect sections (hızlı, senkron) ==========
    const existingSections = await prisma.section.count({ where: { courseId: course.id } })
    const existingSectionRows =
      existingSections > 0
        ? await prisma.section.findMany({
            where: { courseId: course.id },
            select: { pageStart: true, pageEnd: true, title: true },
            orderBy: { order: "asc" },
          })
        : []

    if (existingSections > 0 && sectionsLookValid(existingSectionRows)) {
      console.log(
        `[PROCESS] Devam: ${existingSections} bölüm zaten var (sayfa aralıkları geçerli) — bölüm algılama atlanıyor`,
      )
    } else if (existingSections === 0) {
      console.log(`[PROCESS] İlk işleme: ${course.name} (${totalPages} sayfa)...`)

      const pageTexts = await extractAllText(pdfBuffer)

      // ⚠️ PDF KALİTE KONTROLÜ — aranabilir PDF yerel metinle bölümlenir; görsel okuma arka planda yine çalışır
      const pdfSearchability = assessPdfSearchability(pageTexts)
      const pdfQuality = checkPdfQuality(pageTexts, totalPages)
      const isScannedPdf = pdfSearchability.isNonSearchable

      if (pdfSearchability.isSearchable) {
        console.log(
          `[PROCESS] ✅ ${NATIVE_TEXT_LOG_MESSAGE} (${pdfSearchability.totalChars} karakter, ${pageTexts.length} sayfa, ortalama ${Math.round(pdfSearchability.avgCharsPerPage)}/sayfa)`,
        )
      } else if (isScannedPdf) {
        console.warn(`[PROCESS] 📷 Taranmış PDF algılandı (metin katmanı yok). Görsel OCR yoluna yönlendiriliyor — RED EDİLMEDİ.`)
      } else if (pdfQuality.isPartiallySearchable) {
        console.warn(`[PROCESS] ⚠️ KISMEN SEARCHABLE: ${pdfQuality.message}`)
      }

      await prisma.course.update({
        where: { slug },
        data: { processedPages: isScannedPdf ? totalPages : pageTexts.length }
      })
      console.log(`[PROCESS] ${isScannedPdf ? "Taranmış PDF — OCR bekliyor" : `${pageTexts.length} sayfadan metin çıkarıldı`}.`)

      const geminiKeys = (process.env.GEMINI_API_KEYS || process.env.GOOGLE_GENERATIVE_AI_API_KEY || "").split(",").filter(k => k.trim())

      let sections: DetectedSection[] = []
      let tocAttempts = 0
      const MAX_TOC_ATTEMPTS = 3

      if (isScannedPdf) {
        // Taranmış PDF: metin tabanlı bölümleme çalışmaz → görsel multimodal bölümleme veya tek bölüm
        console.log(`[PROCESS] 📷 Taranmış PDF bölüm algılama: görsel multimodal yol deneniyor...`)
        if (course.geminiFileUri && geminiKeys.length > 0) {
          try {
            const multimodalSections = await detectSectionsMultimodal(course.geminiFileUri, geminiKeys[0])
            if (multimodalSections.length >= 1) {
              sections = multimodalSections.map((s) => ({
                title: s.title,
                pageStart: Math.max(1, s.pageStart),
                pageEnd: Math.min(totalPages, s.pageEnd),
                content: SCANNED_PDF_PENDING_OCR,
              }))
              console.log(`[PROCESS] ✅ Görsel bölümleme: ${sections.length} bölüm algılandı (OCR arka planda dolduracak).`)
            }
          } catch (mmErr: any) {
            console.warn(`[PROCESS] ⚠️ Görsel bölümleme başarısız: ${mmErr.message?.substring(0, 120)}`)
          }
        }
        if (sections.length === 0) {
          sections = [{
            title: "Bölüm İçeriği (Ana Metin)",
            pageStart: 1,
            pageEnd: totalPages,
            content: SCANNED_PDF_PENDING_OCR,
          }]
          console.log(`[PROCESS] 📷 Tek bölüm modu: tüm kitap (${totalPages} sayfa) OCR ile işlenecek.`)
        }
      } else {
        const programSlug = course.program?.slug || ""
        const aiMode = course.program?.aiMode || "general"
        const staticMeta = getCourseBySlug(slug)
        const processingProfile = getDocumentProcessingProfile({
          slug,
          name: course.name,
          sourceKind: staticMeta?.sourceKind,
          sourceKindLabel: staticMeta?.sourceKindLabel,
          gridGroup: staticMeta?.gridGroup,
          programSlug,
          aiMode,
          totalPages: pageTexts.length,
        })

        console.log(`[PROCESS] ${formatProcessingProfileLog(processingProfile, slug)}`)

        if (processingProfile.mode === "single") {
          sections = buildSingleSectionFromPages(pageTexts, course.name)
        } else {
          while (sections.length === 0 && tocAttempts < MAX_TOC_ATTEMPTS) {
            tocAttempts++
            console.log(`[PROCESS] 🔄 Sistematik bölüm algılama (Deneme ${tocAttempts}/${MAX_TOC_ATTEMPTS})...`)

            const result = await detectSectionsSystematic(pageTexts, {
              geminiFileUri: course.geminiFileUri,
              geminiKeys,
              logCourseSlug: slug,
            })

            const isLastAttempt = tocAttempts >= MAX_TOC_ATTEMPTS
            if (result && result.sections.length >= 2 && (result.validation.valid || isLastAttempt)) {
              sections = sectionsToDetected(result.sections, pageTexts)
              console.log(
                `[PROCESS] ✅ Sistematik: ${result.sections.length} bölüm (${result.titleSource}, doğrulama skoru ${result.validation.score}${!result.validation.valid ? " - Son deneme kabulü" : ""})`
              )
              break
            }

            if (result) {
              console.warn(
                `[PROCESS] ⚠️ Sistematik algılama yetersiz (skor ${result.validation.score}): ${result.validation.errors.join("; ")}`
              )
            }

            if (tocAttempts < MAX_TOC_ATTEMPTS) {
              const waitMinutes = Math.min(Math.pow(2, tocAttempts - 1), 5)
              const waitMs = waitMinutes * 60000
              console.log(`[PROCESS] ⏱️ ${waitMinutes} dakika beklenip tekrar denenecek...`)
              await new Promise((resolve) => setTimeout(resolve, waitMs))
            }
          }
        }

      }

    // Bölüm algılanamazsa dur — tek parça veya elle tablo yok (otonom sistem).
    if (sections.length === 0) {
      // 🚀 Zeliha Prosedürleri / Kısa Belgeler için KORUMA KALKANI (Fallback)
      // Eğer doküman 60 sayfadan kısaysa ve AI "İçindekiler" bulamadıysa hata verme, 
      // tüm dokümanı tek bir "Genel İçerik" bölümü olarak kaydet!
      if (course.totalPages <= 60) {
        console.log(`[PROCESS] ⚠️ İçindekiler tablosu bulunamadı ama belge kısa (${course.totalPages} sayfa). Tek parça (Genel İçerik) olarak işleniyor.`);
        sections = [{
          title: "Genel İçerik",
          pageStart: 1,
          pageEnd: course.totalPages,
          content: "",
          module: "1"
        }];
      } else {
        releaseProcessing(slug)
        await prisma.course.update({ where: { slug }, data: { status: "error" } })
        console.error(`[PROCESS] 🛑 Bölüm algılama başarısız — işlem durduruldu (${course.name}).`)
        return NextResponse.json(
          {
            error:
              "PDF bölümleri otomatik algılanamadı (içindekiler okunamadı veya doğrulama geçmedi). Kitabın fiziksel sayfa sırasına göre içindekiler sayfasını kontrol edip PDF'i yeniden yükleyin.",
          },
          { status: 422 }
        )
      }
    }

    // ⚠️ İÇİNDEKİLER / ÖNSÖZ / KAPAK FİLTRESİ
    // Bu sayfalar not üretimi için anlamsızdır — filtrelenir
    const TOC_KEYWORDS = ["İÇİNDEKİLER", "ÖNSÖZ", "FOREWORD", "TABLE OF CONTENTS", "PREFACE", "SUNUŞ"]
    sections = sections.filter(sec => {
      const titleUpper = sec.title.toLocaleUpperCase("tr-TR")
      const contentFirst500 = sec.content.substring(0, 500).toLocaleUpperCase("tr-TR")
      const isTocOrForeword = TOC_KEYWORDS.some(kw => titleUpper.includes(kw) || contentFirst500.includes(kw))
      if (isTocOrForeword && sec.content.length < 3000) {
        console.log(`[PROCESS] 🗑️ İçindekiler/önsöz filtresi: "${sec.title}" (Sayfa ${sec.pageStart}-${sec.pageEnd}) atlandı.`)
        return false
      }
      return true
    })

    console.log(`[PROCESS] ${sections.length} bölüm algılandı (İçindekiler filtresi sonrası).`)

    // ⚠️ KAYNAKÇA BÖLÜMÜ FİLTRESİ (TAMAMEN SİLME)
    // Kaynakça sınavda sorulmaz — UI'da veya veritabanında yer kaplamaması için tamamen atılır
    const BIBLIO_KEYWORDS = ["KAYNAKÇA", "KAYNAKLAR", "REFERENCES", "BİBLİYOGRAFYA", "SINAV ALT KONU"]
    sections = sections.filter(sec => {
      const titleUpper = sec.title.toLocaleUpperCase("tr-TR")
      const isBibliography = BIBLIO_KEYWORDS.some(kw => titleUpper.includes(kw))
      if (isBibliography) {
        console.log(`[PROCESS] 🗑️ Kaynakça filtresi: "${sec.title}" (Sayfa ${sec.pageStart}-${sec.pageEnd}) veritabanına eklenmeyecek.`)
        return false
      }
      return true
    })

    console.log(`[PROCESS] ${sections.length} bölüm algılandı (Tüm filtreler sonrası).`)

    // Aranabilir PDF: yerel metin bölüm ham içeriğine yazılır — görsel okuma arka planda yapılır (şema/resim kaçmasın)
    if (pdfSearchability.isSearchable) {
      for (let i = 0; i < sections.length; i++) {
        const nativeRange = joinPageTextsForRange(
          pageTexts,
          sections[i].pageStart,
          sections[i].pageEnd,
        )
        const prepared = prepareSearchablePdfSectionContent(
          nativeRange.length >= sections[i].content.length
            ? nativeRange
            : sections[i].content,
        )
        if (prepared !== sections[i].content) {
          console.log(
            `[PROCESS] 📄 ${NATIVE_TEXT_LOG_MESSAGE} — "${sections[i].title}" (${prepared.length} karakter)`,
          )
          sections[i].content = prepared
        }
      }
    }

    for (let i = 0; i < sections.length; i++) {
      await prisma.section.create({
        data: {
          courseId: course.id,
          title: sections[i].title,
          order: i + 1,
          pageStart: sections[i].pageStart,
          pageEnd: sections[i].pageEnd,
          rawContent: sections[i].content,
          module: sections[i].module || "Genel",
          processed: false,
          notes: null,
        }
      })
    }
  } else {
    console.log(`[PROCESS] Devam: ${existingSections} bölüm zaten var, kaldığı yerden devam ediliyor...`)
  }

  // ========== PHASE 3+4: AI Analysis + Schedule — ARKA PLANDA ==========
  // İşlem veritabanı kuyruğuna (Job Queue) eklenir. Sunucu kapansa bile güvendedir.
  try {
    const { enqueueCourseProcessJob } = await import("@/lib/job-processor")
    await enqueueCourseProcessJob(slug, forceRetry)
  } catch (error) {
    console.error("[QUEUE_ERROR] Kuyruğa eklenemedi:", error)
  }

  return NextResponse.json({
    success: true,
    message: "İşleme başlatıldı",
    status: "processing",
    workerLive: true,
  })
} catch (error: any) {
  console.error("[PROCESS_FATAL]", error);
  return NextResponse.json({ error: error.message, stack: error.stack }, { status: 500 })
}
}

// ==================== BACKGROUND PROCESSING ====================
// processInBackground artık @/lib/background-processor.ts dosyasında.
// Circular dependency'yi kırmak için oraya taşındı (job-processor ↔ route.ts).
export { processInBackground } from "@/lib/background-processor"
